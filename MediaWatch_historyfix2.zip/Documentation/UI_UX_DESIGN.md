# MediaWatch - UI/UX Design

## Overview

MediaWatch prioritizes simplicity and ease of use. The interface is minimal, focused, and consistent across iPhone and iPad with adaptive layouts.

---

## 1. Design Principles

### 1.1 Core Principles
- **Simplicity First**: Every action should be obvious
- **Minimal Taps**: Common tasks in 1-3 taps
- **Progressive Disclosure**: Show more details on demand
- **Consistency**: Same patterns across all screens
- **Accessibility**: VoiceOver and Dynamic Type support

### 1.2 Visual Design
- Clean, minimal aesthetic
- System fonts (SF Pro)
- System colors with semantic meaning
- Generous white space
- Clear visual hierarchy

---

## 2. Navigation Structure

### 2.1 iPhone (Tab Bar)

```
┌─────────────────────────────┐
│                             │
│                             │
│      Content Area           │
│                             │
│                             │
├─────────────────────────────┤
│ Library │ Search │ Settings │
└─────────────────────────────┘
```

**Tabs:**
1. **Library** (list.bullet) - Lists and content
2. **Search** (magnifyingglass) - Find and add
3. **Settings** (gear) - Preferences

### 2.2 iPad (Split View)

```
┌─────────┬─────────────┬──────────────┐
│         │             │              │
│ Sidebar │   Content   │    Detail    │
│  Lists  │   Titles    │  Title View  │
│         │             │              │
└─────────┴─────────────┴──────────────┘
```

**Columns:**
1. **Sidebar** - All lists
2. **Content** - Titles in selected list
3. **Detail** - Full title detail

---

## 3. Screen Specifications

### 3.1 Library Tab (iPhone)

#### Lists View

```
┌─────────────────────────────┐
│ Library              [Edit] │
├─────────────────────────────┤
│ ┌─────────────────────────┐ │
│ │ 📺 Watchlist      12 ▶  │ │
│ │    ████████░░  75%      │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ 🎬 Favorites       8 ▶  │ │
│ │    ██████████  100%     │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ 👥 Shared          5 ▶  │ │
│ │    ████░░░░░░  40%      │ │
│ └─────────────────────────┘ │
│                             │
│    [+ Create New List]      │
└─────────────────────────────┘
```

**Features:**
- List name with optional icon
- Item count
- Watch progress bar
- Shared indicator
- Swipe to delete/share
- Pull to refresh
- Edit mode for reordering

#### List Detail View

```
┌─────────────────────────────┐
│ ◀ Watchlist    [Filter][+]  │
├─────────────────────────────┤
│ ┌─────┬───────────────────┐ │
│ │     │ Breaking Bad      │ │
│ │ 🖼  │ 2008 • TV         │ │
│ │     │ ████░░ 62/62  ✓   │ │
│ └─────┴───────────────────┘ │
│ ┌─────┬───────────────────┐ │
│ │     │ The Matrix        │ │
│ │ 🖼  │ 1999 • Movie      │ │
│ │     │ ○ Not watched     │ │
│ └─────┴───────────────────┘ │
│ ┌─────┬───────────────────┐ │
│ │     │ Inception      👍 │ │
│ │ 🖼  │ 2010 • Movie      │ │
│ │     │ ● Watched         │ │
│ └─────┴───────────────────┘ │
└─────────────────────────────┘
```

**Features:**
- Poster thumbnail
- Title, year, type
- Watch status/progress
- Liked indicator
- Tap for detail
- Swipe actions (delete, move)
- Sort options (date added, title, year, progress)
- Filter options (watched, type, liked)

### 3.2 Title Detail View

#### Movie Detail

```
┌─────────────────────────────┐
│ ◀                   [Share] │
├─────────────────────────────┤
│  ┌─────────────────────┐    │
│  │                     │    │
│  │    Backdrop Image   │    │
│  │                     │    │
│  └─────────────────────┘    │
│                             │
│  Inception                  │
│  2010 • 148min • PG-13      │
│  Sci-Fi, Action, Thriller   │
│                             │
│  ┌─────┬───────┬──────┐     │
│  │  ○  │   ❤️  │  📝  │     │
│  │Watch│ Like  │ Note │     │
│  └─────┴───────┴──────┘     │
│                             │
│  Overview                   │
│  A thief who steals...      │
│  [Read More]                │
│                             │
│  In Lists                   │
│  • Watchlist                │
│  • Favorites                │
│  [+ Add to List]            │
│                             │
│  Notes (1)                  │
│  ┌─────────────────────┐    │
│  │ Great rewatch! The...│   │
│  └─────────────────────┘    │
└─────────────────────────────┘
```

#### TV Show Detail

```
┌─────────────────────────────┐
│ ◀                   [Share] │
├─────────────────────────────┤
│  [Backdrop Image]           │
│                             │
│  Breaking Bad               │
│  2008-2013 • 5 Seasons      │
│  Drama, Crime, Thriller     │
│                             │
│  ┌─────┬───────┬──────┐     │
│  │ 62  │   👍  │  📝  │     │
│  │/62  │ Liked │ Note │     │
│  └─────┴───────┴──────┘     │
│                             │
│  Overview...                │
│                             │
│  Episodes          [Mark All]│
│  ┌─────────────────────────┐│
│  │ ▼ Season 1    [7/7] ✓  ││
│  ├─────────────────────────┤│
│  │  S01E01 Pilot      [✓] ││
│  │  S01E02 Cat's...   [✓] ││
│  └─────────────────────────┘│
│  ┌─────────────────────────┐│
│  │ ▶ Season 2    [5/13]   ││
│  └─────────────────────────┘│
└─────────────────────────────┘
```

### 3.3 Search Tab

#### Search View

```
┌─────────────────────────────┐
│  🔍 Search movies & TV      │
├─────────────────────────────┤
│  [Movies] [TV Shows] [All]  │
├─────────────────────────────┤
│ ┌─────┬───────────────────┐ │
│ │     │ Dune              │ │
│ │ 🖼  │ 2021 • Movie      │ │
│ │     │ 8.1 ★             │ │
│ └─────┴───────────────────┘ │
│ ┌─────┬───────────────────┐ │
│ │     │ Dune: Part Two    │ │
│ │ 🖼  │ 2024 • Movie      │ │
│ │     │ 8.4 ★             │ │
│ └─────┴───────────────────┘ │
│ ┌─────┬───────────────────┐ │
│ │     │ Dune (Mini...)    │ │
│ │ 🖼  │ 2000 • TV         │ │
│ │     │ 7.1 ★             │ │
│ └─────┴───────────────────┘ │
│                             │
│  Showing 20 of 156 results  │
└─────────────────────────────┘
```

**Features:**
- Search bar with clear button
- Type filter toggle
- Results with poster, title, year
- TMDb rating
- Tap to add
- Infinite scroll pagination
- Recent searches (optional)

### 3.4 Add Title Flow

#### Step 1: Select Lists (Required)

```
┌─────────────────────────────┐
│ ◀ Add to Lists       [Next] │
├─────────────────────────────┤
│                             │
│  Dune (2021)                │
│  Select one or more lists   │
│                             │
│ ┌─────────────────────────┐ │
│ │ ☑ Watchlist             │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ ☐ Favorites             │ │
│ └─────────────────────────┘ │
│ ┌─────────────────────────┐ │
│ │ ☐ Sci-Fi Collection     │ │
│ └─────────────────────────┘ │
│                             │
│    [+ Create New List]      │
│                             │
└─────────────────────────────┘
```

#### Step 2: Optional Details

```
┌─────────────────────────────┐
│ ◀ Details            [Save] │
├─────────────────────────────┤
│                             │
│  Dune (2021)                │
│  Adding to: Watchlist       │
│                             │
│  How did you like it?       │
│  ┌─────┬───────┬──────┐     │
│  │ 👎  │   😐  │  👍  │     │
│  └─────┴───────┴──────┘     │
│                             │
│  Add a note (optional)      │
│  ┌─────────────────────┐    │
│  │                     │    │
│  │                     │    │
│  └─────────────────────┘    │
│                             │
│        [Skip & Save]        │
│                             │
└─────────────────────────────┘
```

### 3.5 Settings Tab

```
┌─────────────────────────────┐
│ Settings                    │
├─────────────────────────────┤
│                             │
│ LIBRARY                     │
│ ┌─────────────────────────┐ │
│ │ Default List    Watchlist│ │
│ │ Image Quality     Medium │ │
│ │ Show Watched         [✓] │ │
│ └─────────────────────────┘ │
│                             │
│ SYNC                        │
│ ┌─────────────────────────┐ │
│ │ iCloud Sync          [✓] │ │
│ │ Last Sync      Just now  │ │
│ │ Sync Status       ● OK   │ │
│ └─────────────────────────┘ │
│                             │
│ BACKUP                      │
│ ┌─────────────────────────┐ │
│ │ Export Data           ▶  │ │
│ │ Import Data           ▶  │ │
│ │ Export to iCloud      ▶  │ │
│ └─────────────────────────┘ │
│                             │
│ ABOUT                       │
│ ┌─────────────────────────┐ │
│ │ Version           1.0.0  │ │
│ │ Clear Image Cache     ▶  │ │
│ │ Privacy Policy        ▶  │ │
│ └─────────────────────────┘ │
└─────────────────────────────┘
```

### 3.6 Backup/Export View

```
┌─────────────────────────────┐
│ ◀ Export Data               │
├─────────────────────────────┤
│                             │
│  Export your library        │
│                             │
│  FORMAT                     │
│  ┌─────────────────────────┐│
│  │ ◉ JSON (data only)      ││
│  │ ○ ZIP (data + images)   ││
│  └─────────────────────────┘│
│                             │
│  INCLUDE                    │
│  ┌─────────────────────────┐│
│  │ ☑ All Lists             ││
│  │ ☑ Watch History         ││
│  │ ☑ Notes                 ││
│  │ ☐ Private Notes         ││
│  └─────────────────────────┘│
│                             │
│  Summary:                   │
│  3 lists, 25 titles,        │
│  62 episodes, 5 notes       │
│                             │
│       [Export Now]          │
│                             │
└─────────────────────────────┘
```

---

## 4. iPad-Specific Layouts

### 4.1 Three-Column Split View

```
┌────────────┬────────────────────┬─────────────────────┐
│            │                    │                     │
│   LISTS    │      TITLES        │      DETAIL         │
│            │                    │                     │
│ Watchlist  │ [Filter] [Sort]    │ ┌───────────────┐   │
│ Favorites● │                    │ │ Backdrop      │   │
│ Sci-Fi     │ ┌────┬─────────┐   │ └───────────────┘   │
│ Shared     │ │ 🖼 │ Dune    │   │                     │
│            │ │    │ 2021    │   │ Inception           │
│            │ └────┴─────────┘   │ 2010 • 148min       │
│            │ ┌────┬─────────┐   │                     │
│            │ │ 🖼 │ Arrival │   │ [Watch][Like][Note] │
│            │ │    │ 2016    │   │                     │
│            │ └────┴─────────┘   │ Overview...         │
│            │                    │                     │
│ [+ New]    │                    │ Episodes...         │
│            │                    │                     │
└────────────┴────────────────────┴─────────────────────┘
```

### 4.2 iPad Features

- **Drag & Drop**: Drag titles between lists in sidebar
- **Multi-Select**: Select multiple titles for batch operations
- **Keyboard Shortcuts**:
  - ⌘N: New list
  - ⌘F: Search
  - ⌘⌫: Delete
  - Space: Toggle watched
  - ⌘1/2/3: Switch tabs
- **Context Menus**: Right-click for actions
- **Hover States**: Preview info on hover

---

## 5. Components Library

### 5.1 Title Card

```
┌─────────────────────────────────┐
│ ┌─────┐                         │
│ │     │  Title Name          👍 │
│ │ 🖼  │  2024 • Movie           │
│ │     │  ████░░░░ 4/10         │
│ └─────┘                         │
└─────────────────────────────────┘
```

**Variants:**
- Compact (list view)
- Large (grid view)
- Minimal (episode list)

### 5.2 Progress Indicator

**Circular (TV Shows):**
```
  ┌───┐
 /     \
│  62   │
│ ─────  │
│  62   │
 \     /
  └───┘
```

**Linear (Lists):**
```
████████░░░░░░░░ 50%
```

### 5.3 Watch Button

**States:**
- Unwatched: `○`
- Watched: `●`
- Partial (TV): `◐`

### 5.4 Liked Status

**States:**
- Liked: `👍` or `heart.fill`
- Neutral: `😐` or `minus.circle`
- Disliked: `👎` or `hand.thumbsdown`

### 5.5 Shared Badge

```
┌────────────┐
│ 👥 Shared  │
└────────────┘
```

---

## 6. User Flows

### 6.1 Add First Title

```
Open App → Search Tab → Enter Query → Tap Result →
Select List → (Optional: Rate, Note) → Save →
Confirmation → View in Library
```

### 6.2 Share a List

```
Library → List → ••• Menu → Share →
System Share Sheet → Select Contact →
Send Invite → Recipient Accepts →
List Appears for Both
```

### 6.3 Mark Episode Watched

```
Library → List → TV Show → Season →
Tap Episode Row → Episode Marked →
Show Progress Updated
```

### 6.4 Export Backup

```
Settings → Backup → Export →
Select Format → Select Options →
Export → Share Sheet → Save/Send
```

### 6.5 Import from Backup

```
Settings → Backup → Import →
Select File → Preview Data →
Choose Merge/Replace → Confirm →
Data Imported
```

---

## 7. Empty States

### 7.1 No Lists

```
┌─────────────────────────────┐
│                             │
│         📋                  │
│                             │
│    No lists yet             │
│                             │
│  Create your first list to  │
│  start tracking content     │
│                             │
│    [Create List]            │
│                             │
└─────────────────────────────┘
```

### 7.2 Empty List

```
┌─────────────────────────────┐
│                             │
│         🎬                  │
│                             │
│    This list is empty       │
│                             │
│  Search for movies or TV    │
│  shows to add them here     │
│                             │
│    [Search]                 │
│                             │
└─────────────────────────────┘
```

### 7.3 No Search Results

```
┌─────────────────────────────┐
│                             │
│         🔍                  │
│                             │
│    No results found         │
│                             │
│  Try a different search     │
│  term or check spelling     │
│                             │
└─────────────────────────────┘
```

---

## 8. Animations & Transitions

### 8.1 Navigation
- Standard iOS push/pop transitions
- Sheet presentations for modals
- Full-screen cover for search results

### 8.2 State Changes
- Smooth progress bar animations
- Fade for watch/liked toggles
- Scale animation for added feedback

### 8.3 List Operations
- Row insertion/deletion animations
- Reorder drag animation
- Swipe action reveal

---

## 9. Accessibility

### 9.1 VoiceOver
- All elements labeled
- Grouped related content
- Custom actions for swipe gestures
- Progress announcements

### 9.2 Dynamic Type
- Support all text sizes
- Scale layouts appropriately
- Minimum tap targets 44pt

### 9.3 Reduce Motion
- Respect system setting
- Provide non-animated alternatives

### 9.4 Color Contrast
- WCAG AA compliance
- Avoid color-only indicators

---

## 10. Dark Mode

All screens support both light and dark modes using semantic system colors:

- Background: `systemBackground`
- Secondary: `secondarySystemBackground`
- Text: `label`, `secondaryLabel`
- Tint: `accentColor` (user customizable)

---

## 11. Localization Considerations

- All strings externalized
- Support RTL layouts
- Date/number formatting
- Pluralization rules
- Avoid text in images

---

## 12. Error States

### 12.1 Network Error
```
"Unable to load results. Check your connection."
[Retry]
```

### 12.2 Sync Error
```
"Sync failed. Your changes are saved locally."
[View Details]
```

### 12.3 iCloud Unavailable
```
"Sign in to iCloud to sync across devices."
[Open Settings]
```
